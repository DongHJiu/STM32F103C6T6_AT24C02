#include "stm32f10x.h"                  // Device header
#include "OLED.h"
#include "Delay.h"
#include "LED.h"
#include "IIC.h"

unsigned char data;
int i;

int main(void){
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
 	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_OD;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;
 	GPIO_Init(GPIOB, &GPIO_InitStructure);
	GPIO_WriteBit(GPIOB,GPIO_Pin_7,Bit_RESET);
	OLED_Init();
	
	First_I2C_GPIO();
	//At24c02Write(3,3);
	Delay_ms(500);
			for(i=0;i<200;i++){
			At24c02Write(i,0);
		}
	while(1){
		//data = At24c02Read(50);

		OLED_ShowNum(1,1,3,4);
		Delay_ms(2000);
	}
}
